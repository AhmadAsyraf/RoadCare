package com.example.approadcare;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements OnClickListener {

    Button btnAbout, btnMap, btnNews, btnReport;

    Toolbar myToolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAbout = findViewById(R.id.btn_about);
        btnMap = findViewById(R.id.btn_Map);
        btnReport = findViewById(R.id.btn_Report);


        btnAbout.setOnClickListener(this);
        btnMap.setOnClickListener(this);
        btnReport.setOnClickListener(this);


        myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle(R.string.app_name);
    }

    @Override
    public void onClick(View view) {
        if (view == btnAbout) {
            Intent intent = new Intent(this, AboutActivity.class);
            startActivity(intent);
        } else if (view == btnMap) {
            Intent intent = new Intent();
            intent.setClass(getApplicationContext(), MapsActivity.class);
            startActivity(intent);

        }else if (view == btnReport) {
            Intent intent = new Intent();
            intent.setClass(getApplicationContext(), ReportActivity.class);
            startActivity(intent);
        }
    }

    public void openUrl3(View view) {
        String url = "https://192.168.126.1/mobile/news.php"; // web URL

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.item_about) {
            Intent aboutIntent = new Intent(this, AboutActivity.class);
            startActivity(aboutIntent);
        } else if (item.getItemId() == R.id.item_map) {
            Intent mapIntent = new Intent(this, MapsActivity.class);
            startActivity(mapIntent);
        } else if (item.getItemId() == R.id.item_news) {
            String url = "https://192.168.126.1/mobile/about_us.php";
            Intent newsIntent = new Intent(Intent.ACTION_VIEW);
            newsIntent.setData(Uri.parse(url));
            startActivity(newsIntent);
        } else if (item.getItemId() == R.id.item_report) {
            Intent reportIntent = new Intent(this, ReportActivity.class);
            startActivity(reportIntent);}
            return false;

        }


    }
