package com.example.approadcare;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ReportActivity extends AppCompatActivity implements View.OnClickListener {

    Toolbar reportToolbar;

    Button btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        btnSubmit = findViewById(R.id.btn_submit);
        btnSubmit.setOnClickListener(this);

        reportToolbar = findViewById (R.id.report_toolbar);
        setSupportActionBar(reportToolbar);
        getSupportActionBar().setTitle("Report");

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }
    public boolean onOptionsItemSelected (MenuItem item){
        if(item.getItemId() == android.R.id.home){
            super.onBackPressed();
        }
        return true;
    }
    @Override
    public void onClick(View view) {
        if (view == btnSubmit) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
    }
}