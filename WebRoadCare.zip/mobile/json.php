<?php
// Require the database connection file
require_once('dbconn.php');

// Check if $link is successfully established
if (!$link) {
    die('Error: Unable to connect to MySQL');
}

// Query to select all rows from the "map" table
$query = "SELECT * FROM map";

// Execute the query
$result = mysqli_query($link, $query);

// Check if the query was successful
if (!$result) {
    die('Error: Unable to execute query');
}

// Declare an array to hold the results
$output = array();

// Fetch each row from the result set and add it to the output array
while ($row = mysqli_fetch_assoc($result)) {
    $output[] = $row;
}

// Convert the array to JSON
$json = json_encode($output);

// Set the content type header to JSON
header("Content-Type: application/json");

// Output the JSON
echo $json;

// Close the database connection
mysqli_close($link);
?>
