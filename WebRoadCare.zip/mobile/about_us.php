<!DOCTYPE html>
<html lang="en">

	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="keywords" content="HTML Template, site template, seo, marketing, creative, corporate, modern, multipurpose, one page, business, responsive, minimal, saas, startup">
		<meta name="author" content="LiquidThemes">
		<meta name="description" content="Hub is a HTML template with high performance, and award-winning design collection.">
		<meta property="og:title" content="Hub HTML template">
		<meta property="og:description" content="Hub is a HTML template with high performance, and award-winning design collection.">
		<meta property="og:type" content="website">
		<meta property="og:image" content="./assets/images/common/og-image.jpg">

		<link rel="stylesheet" href="./assets/vendors/liquid-icon/lqd-essentials/lqd-essentials.min.css">
		<link rel="stylesheet" href="./assets/css/theme.min.css">
		<link rel="stylesheet" href="./assets/css/utility.min.css">
		<link rel="stylesheet" href="./assets/css/demo/creative-services.css">

		<!-- Fonts -->
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Chivo:wght@400;700&display=swap" rel="stylesheet">

		<title>Creative Services</title>
	</head>

	<body class="lqd-cc-outer-hidden" data-lqd-cc="true" data-mobile-nav-breakpoint="1199" data-mobile-nav-style="modern" data-mobile-nav-scheme="dark" data-mobile-nav-trigger-alignment="right" data-mobile-header-scheme="gray" data-mobile-secondary-bar="false" data-mobile-logo-alignment="default" data-overlay-onmobile="false">
		<div id="wrap">

			<div class="lqd-sticky-placeholder hidden"></div>
			<header class="main-header main-header-overlay sticky-header-noshadow main-header-dynamiccolors" data-sticky-header="true" data-sticky-options='{ "disableOnMobile": true, "stickyTrigger" : "first-section", "dynamicColors" : true }'>
				<div class="lqd-head-sec-wrap lqd-hide-onstuck relative pr-35 pl-20 md:hidden">
					<div class="lqd-head-sec w-full flex items-stretch justify-between">
						<div class="col-auto lqd-head-col flex-grow-1 justify-start">
							<div class="header-module module-logo no-rotate navbar-brand-plain pt-40 pb-30">
								<a class="navbar-brand" href="index.php" rel="home">
									<span class="navbar-brand-inner">
										<img class="logo-dark" src="./assets/images/demo/asymmetric-agency/logo.svg" alt="Hub Theme">
										<img class="logo-default" src="./assets/images/demo/asymmetric-agency/logo-light.svg" alt="Hub Theme">
									</span>
								</a>
							</div>
						</div>
						<div class="col-auto lqd-head-col flex-grow-1 justify-end">
							<div class="header-module module-primary-nav static">
								<div class="navbar-collapse lqd-submenu-default-style inline-flex flex-col items-stretch h-full" id="main-header-collapse" aria-expanded="false" role="navigation">
									<ul class="main-nav lqd-menu-counter-right main-nav-hover-default flex reset-ul flex-nowrap items-stretch justify-end link-16 link-medium link-white" data-submenu-options='{"toggleType": "fade", "handler": "mouse-in-out"}' data-localscroll="true" data-localscroll-options='{"itemsSelector":"> li > a", "trackWindowScroll": true, "includeParentAsOffset": true}'>
										<li>
											<a href="index.php">
												Home
												<sup class="link-sup">01</sup>
											</a>
										</li>
										<li>
											<a href="index.php#case-studies">
												How to use
												<sup class="link-sup">02</sup>
											</a>
										</li>
										<li>
											<a href="index.php#expertise">
												About Us
												<sup class="link-sup">03</sup>
											</a>
										</li>
										<li>
											<a href="news.php">
												News
												<sup class="link-sup">04</sup>
											</a>
										</li>
										<li>
											<a href="about_us.php">
												Team
												<sup class="link-sup">05</sup>
											</a>
										</li>
									</ul>
								</div>
							</div>
							<div class="header-module module-button ml-25 module-button lg:hidden">
								<a href="new.php" class="btn btn-solid btn-sm round border-thin leading-1/6em tracking-0/05em rounded-4 bg-black border-black text-13 uppercase text-white hover:bg-white hover:text-black">
									<span class="btn-txt" data-text="Send message">Send message</span>
								</a>
							</div>
						</div>
					</div>
				</div>
				<div class="lqd-stickybar-wrap lqd-stickybar-left lqd-show-onstuck link-black link-medium pointer-events-none md:hidden">
					<div class="lqd-stickybar w-full h-full relative vertical-rl overflow-visible flex justify-between">
						<div class="col lqd-head-col justify-center">
							<div class="py-10 ld-module-sd header-module header-module-rotate ld-module-sd-hover no-rotate ld-module-sd-right pointer-events-auto">
								<button class="nav-trigger style-2 fill-none flex p-0 border-none rounded-full relative bg-transparent text-black items-center justify-center transition-all txt-right collapsed header-sidedrawer horizontal-tb pl-40" type="button" data-ld-toggle="true" data-bs-toggle="collapse" data-toggle-options='{"type" : "hover"}' data-bs-target="#header-sidedrawer" aria-expanded="false" aria-controls="header-sidedrawer" data-lqd-interactive-color="true">
									<span class="bars">
										<span class="bars-inner w-full h-full flex rounded-inherit flex-col">
											<span class="bar relative bg-black transition-all"></span>
											<span class="bar relative bg-black transition-all"></span>
											<span class="bar relative bg-black transition-all"></span>
										</span>
									</span>
									<span class="txt">Menu</span>
								</button>
								<div class="ld-module-dropdown collapse" aria-valuemin="0" aria-valuenow="0" aria-valuemax="100" id="header-sidedrawer" role="slider">
									<div class="ld-sd-wrap">
										<div class="w-full relative flex flex-wrap h-full justify-between -mr-15 -ml-15">
											<div class="w-full flex flex-auto flex-col items-start justify-start px-15">
												<div class="header-module module-logo no-rotate navbar-brand-plain py-45">
													<a class="navbar-brand" href="index.php" rel="home">
														<span class="navbar-brand-inner">
															<img class="logo-light" src="./assets/images/demo/asymmetric-agency/logo-light.svg" alt="Hub Theme">
															<img class="logo-default" src="./assets/images/demo/asymmetric-agency/logo.svg" alt="Hub Theme">
														</span>
													</a>
												</div>
											</div>
											<div class="w-full flex flex-auto flex-col items-start justify-center px-15">
												<div class="header-module no-rotate">
													<div class="lqd-fancy-menu lqd-custom-menu lqd-menu-td-none">
														<ul class="reset-ul" data-localscroll="true" data-localscroll-options='{"itemsSelector":"> li > a", "trackWindowScroll": true, "includeParentAsOffset": true}'>
															<li class="mb-15">
																<a class="flex leading-1/5em hover:text-primary" href="index.php" aria-current="page">
																	Home
																	<sup class="link-sup">01</sup>
																</a>
															</li>
															<li class="mb-15 menu-item-has-children">
																<a class="flex leading-1/5em hover:text-primary" href="index.php#case-studies">How to use
																	<sup class="link-sup">02</sup>
																	<span class="submenu-expander relative"></span>
																</a>
															</li>
															<li class="mb-15">
																<a class="flex leading-1/5em hover:text-primary" href="index.php#expertise">
																	About Us
																	<sup class="link-sup">03</sup>
																</a>
															</li>
															<li class="mb-15">
																<a class="flex leading-1/5em hover:text-primary" href="news.php">
																	News
																	<sup class="link-sup">04</sup>
																</a>
															</li>
															<li>
																<a class="flex leading-1/5em hover:text-primary" href="about_us.php">
																	Team
																	<sup class="link-sup">05</sup>
																</a>
															</li>
														</ul>
													</div>
												</div>
											</div>
											<div class="w-full flex flex-auto flex-col items-start justify-end px-15">
												<div class="ld-fancy-heading">
													<p class="mb-1/5em ld-fh-element font-medium">hub@liquid.com</p>
												</div>
												<div class="ld-fancy-heading ">
													<p class="mb-2em leading-1/5em text-14 ld-fh-element"> Looking for collaboration for your next project? Do not hesitate to contact us to say hello.</p>
												</div>
												<div class="header-module no-rotate">
													<ul class="social-icon social-icon-lg">
														<li>
															<a href="#" target="_blank">
																<svg class="w-20" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="currentColor">
																	<path d="M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z" />
																</svg>
															</a>
														</li>
														<li>
															<a href="#" target="_blank">
																<svg class="w-20" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="currentColor">
																	<path d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z" />
																</svg>
															</a>
														</li>
														<li>
															<a href="#" target="_blank">
																<svg class="w-20" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 496 512" fill="currentColor">
																	<path d="M165.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3.3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6zm-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5.3-6.2 2.3zm44.2-1.7c-2.9.7-4.9 2.6-4.6 4.9.3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9zM244.8 8C106.1 8 0 113.3 0 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 25.8 21.9 38.6 58.6 27.5 72.9 20.9 2.3-16 8.8-27.1 16-33.7-55.9-6.2-112.3-14.3-112.3-110.5 0-27.5 7.6-41.3 23.6-58.9-2.6-6.5-11.1-33.3 2.6-67.9 20.9-6.5 69 27 69 27 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27 13.7 34.7 5.2 61.4 2.6 67.9 16 17.7 25.8 31.5 25.8 58.9 0 96.5-58.9 104.2-114.8 110.5 9.2 7.9 17 22.9 17 46.4 0 33.7-.3 75.4-.3 83.6 0 6.5 4.6 14.4 17.3 12.1C428.2 457.8 496 362.9 496 252 496 113.3 383.5 8 244.8 8zM97.2 352.9c-1.3 1-1 3.3.7 5.2 1.6 1.6 3.9 2.3 5.2 1 1.3-1 1-3.3-.7-5.2-1.6-1.6-3.9-2.3-5.2-1zm-10.8-8.1c-.7 1.3.3 2.9 2.3 3.9 1.6 1 3.6.7 4.3-.7.7-1.3-.3-2.9-2.3-3.9-2-.6-3.6-.3-4.3.7zm32.4 35.6c-1.6 1.3-1 4.3 1.3 6.2 2.3 2.3 5.2 2.6 6.5 1 1.3-1.3.7-4.3-1.3-6.2-2.2-2.3-5.2-2.6-6.5-1zm-11.4-14.7c-1.6 1-1.6 3.6 0 5.9 1.6 2.3 4.3 3.3 5.6 2.3 1.6-1.3 1.6-3.9 0-6.2-1.4-2.3-4-3.3-5.6-2z" />
																</svg>
															</a>
														</li>
													</ul>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="lqd-module-backdrop"></div>
							</div>
						</div>
						<div class="col lqd-head-col justify-center items-center rotate-180">
							<div class="header-module header-module-rotate py-10">
								<div class="lqd-fancy-menu lqd-menu-td-none pos-static">
									<ul class="reset-ul inline-nav flex pointer-events-auto -mr-10 -ml-10">
										<li class="my-10">
											<a href="#" target="_blank" data-lqd-interactive-color="true"> Follow us —</a>
										</li>
										<li class="my-10">
											<a href="#" target="_blank" data-lqd-interactive-color="true"> Fb.</a>
										</li>
										<li class="my-10">
											<a href="#" target="_blank" data-lqd-interactive-color="true"> Ig.</a>
										</li>
										<li class="my-10">
											<a href="#" target="_blank" data-lqd-interactive-color="true"> Tw.</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col lqd-head-col justify-start items-center rotate-180">
							<div class="lqd-fancy-menu lqd-menu-td-none pos-static py-10">
								<ul class="reset-ul inline-nav flex pointer-events-auto -mr-10 -ml-10">
									<li class="my-10">
										<a href="#" target="_blank" data-lqd-interactive-color="true"> En.</a>
									</li>
									<li class="my-10">
										<a href="#" target="_blank" data-lqd-interactive-color="true"> fr.</a>
									</li>
									<li class="my-10">
										<a href="#" target="_blank" data-lqd-interactive-color="true"> Ge.</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="lqd-stickybar-wrap lqd-stickybar-right lqd-show-onstuck pointer-events-none pb-80 md:hidden">
					<div class="lqd-stickybar flex flex-col">
						<div class="col lqd-head-col"></div>
						<div class="col lqd-head-col flex-col items-center justify-center">
							<div class="header-module lqd-active-row-light header-module-rotate py-10">
								<div class="lqd-scrl-indc pointer-events-auto" data-lqd-scroll-indicator="true">
									<a class="pointer-events-auto text-black vertical-rl rotate-180" href="#wrap" data-localscroll="true" data-lqd-interactive-color="true">
										<span class="lqd-scrl-indc-inner flex items-center">
											<span class="lqd-scrl-indc-txt">scroll</span>
											<span class="lqd-scrl-indc-line bg-black-40 w-1 h-60 relative">
												<span class="lqd-scrl-indc-el inline-block w-10 h-10 absolute -top-5 -left-5 rounded-8"></span>
											</span>
										</span>
									</a>
								</div>
							</div>
						</div>
						
					</div>
				</div>
				<div class="lqd-mobile-sec d-lg-flex relative">
					<div class="lqd-mobile-sec-inner float-left navbar-header w-full flex items-stretch">
						<div class="lqd-mobile-modules-container"></div>
						<button type="button" class="justify-end navbar-toggle collapsed nav-trigger flex p-0 border-none rounded-full relative bg-transparent text-black items-center justify-center transition-all style-mobile" data-ld-toggle="true" data-bs-toggle="collapse" data-bs-target="#lqd-mobile-sec-nav" aria-expanded="false" data-toggle-options='{"changeClassnames" : {"html" : "mobile-nav-activated"}}'>
							<span class="sr-only">Toggle navigation</span>
							<span class="bars">
								<span class="bars-inner w-full h-full flex rounded-inherit flex-col">
									<span class="bar bg-black transition-all"></span>
									<span class="bar bg-black transition-all"></span>
									<span class="bar bg-black transition-all"></span>
								</span>
							</span>
						</button>
						<a class="text-start navbar-brand" href="index.php">
							<span class="navbar-brand-inner justify-start">
								<img class="logo-default" src="./assets/images/demo/asymmetric-agency/logo.svg" alt="Hub Theme">
							</span>
						</a>
					</div>
					<div class="lqd-mobile-sec-nav w-full absolute z-index-10">
						<div class="mobile-navbar-collapse navbar-collapse collapse text-white" id="lqd-mobile-sec-nav" aria-expanded="false" role="navigation">
							<ul id="mobile-primary-nav" class="lqd-mobile-main-nav main-nav nav" data-localscroll="true" data-localscroll-options='{"itemsSelector":"> li > a", "trackWindowScroll": true, "includeParentAsOffset": true}'>
								<li>
									<a href="index.php" aria-current="page">Home<sup class="link-sup">01</sup></a>
								</li>
								<li class="menu-item-has-children">
									<a href="index.php#case-studies">
										how to use
										<span class="submenu-expander absolute inline-flex bg-white-5"></span>
										<sup class="link-sup">02</sup>
									</a>
								</li>
								<li>
									<a href="index.php#expertise">About Us<sup class="link-sup">03</sup></a>
								</li>
								<li>
									<a href="news.php">News<sup class="link-sup">04</sup></a>
								</li>
								<li>
									<a href="index.php#contact">Team<sup class="link-sup">05</sup></a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</header>

			<main class="content bg-center-top bg-repeat z-2 bg-white" id="lqd-site-content" style="background-image: url(./assets/images/demo/asymmetric-agency/bg-lines.svg);">
				<div id="lqd-contents-wrap">

					<!-- Start Banner -->
					<section class="lqd-section banner bg-no-repeat bg-cover bg-center transition-all pt-200 pb-230" id="banner"  data-section-luminosity="dark">
						<div class="row-bg-wrap absolute inline-block top-0 right-0 bottom-0 left-0 overflow-hidden">
							<div class="row-bg-inner absolute inline-block top-0 right-0 bottom-0 left-0 transition-all">
								<figure class="row-bg absolute -top-5 -right-5 -bottom-5 -left-5 bg-no-repeat bg-cover bg-center" style="background-image: url(./assets/images/demo/asymmetric-agency/our-approach/banner.jpg);"></figure>
							</div>
						</div>
						<div class="liquid-row-overlay w-full h-full block absolute top-0 left-0 transition-all bg-black-20" ></div>
						<span class="lqd-extra-cursor fixed"></span>
						<div class="container-fluid p-0">
							<div class="row m-0">
								<div class="col col-12 text-center p-0" data-custom-animations="true" data-ca-options='{"triggerHandler":"inview","animationTarget":"all-childs","duration":"1800","delay":"180","ease":"power4.out","direction":"forward","initValues":{"y":120,"transformOriginX":50,"transformOriginY":50,"transformOriginZ":"0px","opacity":0},"animations":{"y":0,"transformOriginX":50,"transformOriginY":50,"transformOriginZ":"0px","opacity":1}}'>
									<div class="lqd-typewriter mb-0">
										<h1 data-typewriter="true">
											I AM
											<del>
												ASYRAF
												<ins>2</ins>
											</del>
											<del>
												SHAHRIL 
												<ins>2</ins>
											</del>
											<del>
												
												<ins>2</ins>
											</del>
											
											
										</h1>
									</div>
								</div>
							</div>
						</div>
					</section>
					<!-- End Banner -->

					<!-- Start About -->
					<section class="lqd-section about pt-65 pb-50" id="about" data-section-luminosity="light">
						<div class="container">
							<div class="row items-center">
								<div class="col col-12 col-md-6 text-start module-first" data-custom-animations="true" data-ca-options='{"triggerHandler":"inview","animationTarget":"h6, h2, p,.lqd-counter, figure","duration":"1800","startDelay":"800","delay":"180","ease":"power4.out","direction":"forward","initValues":{"y":60,"transformOriginX":50,"transformOriginY":50,"transformOriginZ":"0px","opacity":0},"animations":{"y":0,"transformOriginX":50,"transformOriginY":50,"transformOriginZ":"0px","opacity":1}}'>
									<div class="flex flex-col items-start module-title">
										<h6 class="ld-fh-element py-5 px-15 mb-1/25em bg-red-500 rounded-100 text-13 uppercase font-semibold tracking-0/1em text-white">Meet The Team</h6>
										<h2 class="ld-fh-element mb-0 text-28 font-medium leading-1/15em">Our team of four members is working on a mobile application aimed at alerting road users about potential hazards.</h2>
									</div>
								</div>
								<div class="col col-12 col-md-6 col-lg-5 offset-lg-1" data-custom-animations="true" data-ca-options='{"triggerHandler":"inview","animationTarget":"p","duration":"1800","startDelay":"1100","delay":"180","ease":"power4.out","direction":"forward","initValues":{"y":30,"transformOriginX":50,"transformOriginY":50,"transformOriginZ":"0px","opacity":0},"animations":{"y":0,"transformOriginX":50,"transformOriginY":50,"transformOriginZ":"0px","opacity":1}}'>
									<p class="ld-fh-element mb-0 text-16 leading-1/6em text-black">
										With a skilled programmer, web developer, mobile app developer, and a dedicated project manager, we aim to create a user-friendly application for enhanced road safety.
										<br>
										
									</p>
								</div>
							</div>
						</div>
					</section>
					<!-- End About -->

					<!-- Start Icon Box -->
					<section class="lqd-section icon-box pt-25 pb-15 sm:pb-0" data-custom-animations="true" data-ca-options='{"triggerHandler":"inview","animationTarget":"h6, h2, p, .iconbox","duration":"1800","delay":"180","ease":"power4.out","direction":"forward","initValues":{"x":30,"transformOriginX":50,"transformOriginY":50,"transformOriginZ":"0px","opacity":0},"animations":{"x":0,"transformOriginX":50,"transformOriginY":50,"transformOriginZ":"0px","opacity":1}}' data-section-luminosity="light">
						<div class="container">
							<div class="row">
								<div class="col col-6 col-lg-3">
									<div class="iconbox text-align-default iconbox-heading-xs relative flex-col items-center justify-center text-center border-right border-black-10 md:border-0" data-animate-icon="true">
										<div class="iconbox-icon-wrap">
											<figure>
												<img width="205" height="218" src="./assets/images/demo/asymmetric-agency/our-approach/what-we-do-4.jpg" alt="what we do">
											</figure>
										</div>
										<div class="contents">
											<h3 class="mb-15 text-18 leading-1/5em">Web Developer</h3>
											<p>
												<span class="text-15 text-gray-500">AHMAD ASYRAF BIN ZAINUDIN</span>
											</p>
										</div>
									</div>
								</div>
								<div class="col col-6 col-lg-3">
									<div class="iconbox text-align-default iconbox-heading-xs relative flex-col items-center justify-center text-center border-right border-black-10 md:border-0" data-animate-icon="true">
										<div class="iconbox-icon-wrap">
										<figure>
												<img width="205" height="218" src="./assets/images/demo/asymmetric-agency/our-approach/what-we-do-7.png" alt="what we do">
											</figure>
										</div>
										<div class="contents">
											<h3 class="mb-15 text-18 leading-1/5em">Mobile Developer</h3>
											<p>
												<span class="text-15 text-gray-500">SH MOHAMAD SHAHRIL AZRI SH NURSHAHBUDIN</span>
											</p>
										</div>
									</div>
								</div>
								
							</div>
						</div>
						<br>
						<br>
						<br>
						<br>
						<br>
						<br>
					</section>
					<!-- End Icon Box -->
				</div>
			</main>


			<!-- Start Footer -->
			<footer id="site-footer" class="main-footer bg-gray-800 text-gray-400" data-sticky-footer="true" data-sticky-footer-options='{" shadow":"4"}' data-section-luminosity="dark">
				<section class="lqd-section module-top pt-70" data-section-luminosity="dark">
					<div class="container">
						<div class="row items-start">
							<div class="col col-12 col-lg-6">
								<div class="container-fluid pt-40 px-0 border-top border-white-10">
									<div class="row">
										<div class="col col-12 col-md-4 mb-35">
											<div class="lqd-imggrp-img-container mb-35">
												<figure class="max-w-full relative inline-flex flex-grow-1 vertical-top m-0">
													<img src="./assets/images/demo/asymmetric-agency/logo-light.svg" alt="hub logo">
												</figure>
											</div>
										</div>
										<div class="col col-6 col-md-4 mb-35">
											<h3 class="ld-fh-element mb-2/15em text-14 tracking-0/1em text-white"> Road Care</h3>
											<div class="lqd-fancy-menu lqd-custom-menu lqd-menu-td-none">
												<ul class="reset-ul">
													<li class="w-full relative flex items-center flex-wrap mb-5">
														<a class="text-gray-400 hover:text-white" href="#">Company</a>
													</li>
													<li class="w-full relative flex items-center flex-wrap mb-5">
														<a class="text-gray-400 hover:text-white" href="#">Careers</a>
													</li>
													<li class="w-full relative flex items-center flex-wrap mb-5">
														<a class="text-gray-400 hover:text-white" href="#">Press media</a>
													</li>
													<li class="w-full relative flex items-center flex-wrap mb-5">
														<a class="text-gray-400 hover:text-white" href="#">Our Blog</a>
													</li>
													<li class="w-full relative flex items-center flex-wrap">
														<a class="text-gray-400 hover:text-white" href="#">Privacy Policy</a>
													</li>
												</ul>
											</div>
										</div>
										<div class="col col-6 col-md-4 mb-35">
											<h3 class="ld-fh-element mb-2/15em text-14 tracking-0/1em text-white"> Products</h3>
											<div class="lqd-fancy-menu lqd-custom-menu lqd-menu-td-none">
												<ul class="reset-ul">
													<li class="w-full relative flex items-center flex-wrap mb-5">
														<a class="text-gray-400 hover:text-white" href="#">Company</a>
													</li>
													<li class="w-full relative flex items-center flex-wrap mb-5">
														<a class="text-gray-400 hover:text-white" href="#">Careers</a>
													</li>
													<li class="w-full relative flex items-center flex-wrap mb-5">
														<a class="text-gray-400 hover:text-white" href="#">Press media</a>
													</li>
													<li class="w-full relative flex items-center flex-wrap mb-5">
														<a class="text-gray-400 hover:text-white" href="#">Our Blog</a>
													</li>
													<li class="w-full relative flex items-center flex-wrap">
														<a class="text-gray-400 hover:text-white" href="#">Privacy Policy</a>
													</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col col-12 col-md-6 col-lg-3">
								<div class="w-full relative flex flex-col pt-40 border-top border-white-10 mb-35">
									<h3 class="ld-fh-element mb-1/75em text-12 uppercase tracking-0/1em text-white-30"> Need help?</h3>
									<p class="ld-fh-element mb-0/5em text-18 text-white"> +6017-3933235</p>
									<div class="w-full relative h-25"></div>
									<h3 class="ld-fh-element mb-1/75em text-12 uppercase tracking-0/1em text-white-30"> Need support?</h3>
									<p class="ld-fh-element mb-0/5em text-18 text-white">help@roadcare.com</p>
								</div>
							</div>
							<div class="col col-12 col-md-6 col-lg-3">
								<div class=" pt-40 border-top border-white-10 mb-35">
									<h3 class="ld-fh-element mb-1/75em text-14 uppercase tracking-0/1em text-white"> Follow Us</h3>
									<ul class="social-icon social-icon-border-none social-icon-md text-28">
										<li>
											<a class="text-28 text-gray-400 hover:text-white" href="#" target="_blank">
												<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512" fill="currentColor"><path d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h137.25V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.27c-30.81 0-40.42 19.12-40.42 38.73V256h68.78l-11 71.69h-57.78V480H400a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48z"/></svg>
											</a>
										</li>
										<li>
											<a class="text-28 text-gray-400 hover:text-white" href="#" target="_blank">
												<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 512 512" fill="currentColor"><path d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"/></svg>
											</a>
										</li>
										<li>
											<a class="text-28 text-gray-400 hover:text-white" href="#" target="_blank">
												<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512" fill="currentColor"><path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"/></svg>
											</a>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</section>
				<section class="lqd-section module-bottom pb-35" data-section-luminosity="dark">
					<div class="container">
						<div class="row">
							<div class="col col-12">
								<div class="w-full border-top border-white-10 mb-40"></div>
							</div>
							<div class="col col-12 col-md-6">
								<div class="lqd-fancy-menu lqd-menu-td-none -mx-15">
									<ul class="reset-ul inline-nav">
										<li class="mx-15">
											<a class="text-12 text-gray-400 hover:text-white" href="#" target="_blank"> English / Malay</a>
										</li>
										<li class="mx-15">
											<a class="text-12 text-gray-400 hover:text-white" href="#" target="_blank"> English / Malay</a>
										</li>
									</ul>
								</div>
							</div>
							<div class="col col-12 col-md-6 text-end sm:text-start">
								<p class="ld-fh-element mb-0/5em text-14"> © 2024 Roadcare.com.my</p>
							</div>
						</div>
					</div>
				</section>
			</footer>
			<!-- End Footer -->
		</div>

		

		<script src="./assets/vendors/jquery.min.js"></script>
		<script src="./assets/vendors/jquery-ui/jquery-ui.min.js"></script>
		<script src="./assets/vendors/bootstrap/js/bootstrap.min.js"></script>
		<script src="./assets/vendors/gsap/minified/gsap.min.js"></script>
		<script src="./assets/vendors/gsap/minified/ScrollTrigger.min.js"></script>
		<script src="./assets/vendors/gsap/utils/SplitText.min.js"></script>
		<script src="./assets/vendors/fastdom/fastdom.min.js"></script>
		<script src="./assets/vendors/isotope/isotope.pkgd.min.js"></script>
		<script src="./assets/vendors/isotope/packery-mode.pkgd.min.js"></script>
		<script src="./assets/vendors/flickity/flickity.pkgd.min.js"></script>
		<script src="./assets/vendors/lity/lity.min.js"></script>
		<script src="./assets/vendors/particles.min.js"></script>
		<script src="./assets/vendors/fontfaceobserver.js"></script>
		<script src="./assets/vendors/tinycolor-min.js"></script>
		<script src="./assets/vendors/t-js/t.min.js"></script>
		<script src="./assets/js/theme.min.js"></script>
		<script src="./assets/js/liquid-ajax-contact-form.min.js"></script>

		<!-- Start custom cursor -->
		<div class="lqd-cc lqd-cc--inner fixed pointer-events-none"></div>
		<div class="lqd-cc--el lqd-cc-solid lqd-cc-explore flex items-center justify-center rounded-full fixed pointer-events-none">
			<div class="lqd-cc-solid-bg flex absolute lqd-overlay"></div>
			<div class="lqd-cc-solid-txt flex justify-center text-center relative">
				<div class="lqd-cc-solid-txt-inner">Explide</div>
			</div>
		</div>
		<div class="lqd-cc--el lqd-cc-solid lqd-cc-drag flex items-center justify-center rounded-full fixed pointer-events-none">
			<div class="lqd-cc-solid-bg flex absolute lqd-overlay"></div>
			<div class="lqd-cc-solid-ext lqd-cc-solid-ext-left inline-flex items-center">
				<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" style="width: 1em; height: 1em;"><path fill="currentColor" d="M19.943 6.07L9.837 14.73a1.486 1.486 0 0 0 0 2.25l10.106 8.661c.96.826 2.457.145 2.447-1.125V7.195c0-1.27-1.487-1.951-2.447-1.125z"></path></svg>
			</div>
			<div class="lqd-cc-solid-txt flex justify-center text-center relative">
				<div class="lqd-cc-solid-txt-inner">Drag</div>
			</div>
			<div class="lqd-cc-solid-ext lqd-cc-solid-ext-right inline-flex items-center">
				<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" style="width: 1em; height: 1em;"><path fill="currentColor" d="M11.768 25.641l10.106-8.66a1.486 1.486 0 0 0 0-2.25L11.768 6.07c-.96-.826-2.457-.145-2.447 1.125v17.321c0 1.27 1.487 1.951 2.447 1.125z"></path></svg>
			</div>
		</div>
		<div class="lqd-cc--el lqd-cc-arrow inline-flex items-center fixed top-0 left-0 pointer-events-none">
			<svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M60.4993 0V4.77005H8.87285L80 75.9207L75.7886 79.1419L4.98796 8.35478V60.4993H0V0H60.4993Z"/>
			</svg>
		</div>
		<div class="lqd-cc--el lqd-cc-custom-icon rounded-full fixed pointer-events-none">
			<div class="lqd-cc-ci inline-flex items-center justify-center rounded-full relative">
				<svg width="32" height="32" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" style="width: 1em; height: 1em;"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M16.03 6a1 1 0 0 1 1 1v8.02h8.02a1 1 0 1 1 0 2.01h-8.02v8.02a1 1 0 1 1-2.01 0v-8.02h-8.02a1 1 0 1 1 0-2.01h8.02v-8.01a1 1 0 0 1 1.01-1.01z"></path></svg>
			</div>
		</div>
		<div class="lqd-cc lqd-cc--outer fixed top-0 left-0 pointer-events-none"></div>
		<!-- End custom cursor -->

		<template id="lqd-snickersbar">
			<div class="lqd-snickersbar flex flex-wrap lqd-snickersbar-in" data-item-id>
				<div class="lqd-snickersbar-inner flex flex-wrap items-center">
					<div class="lqd-snickersbar-detail">
						<p class="hidden lqd-snickersbar-addding-temp my-0">Adding {{itemName}} to cart</p>
						<p class="hidden lqd-snickersbar-added-temp my-0">Added {{itemName}} to cart</p>
						<p class="my-0 lqd-snickersbar-msg flex items-center my-0"></p>
						<p class="my-0 lqd-snickersbar-msg-done flex items-center my-0"></p>
					</div>
					<div class="lqd-snickersbar-ext ml-4"></div>
				</div>
			</div>
		</template>
		<template id="lqd-temp-sticky-header-sentinel">
			<div class="lqd-sticky-sentinel invisible absolute pointer-events-none"></div>
		</template>
		<div class="lity" role="dialog" aria-label="Dialog Window (Press escape to close)" tabindex="-1" data-modal-type="default">
			<div class="lity-wrap" data-lity-close role="document">
				<div class="lity-loader" aria-hidden="true">Loading...</div>
				<div class="lity-container">
					<div class="lity-content"></div>
				</div>
				<button class="lity-close" type="button" aria-label="Close (Press escape to close)" data-lity-close>&times;</button>
			</div>
		</div>
	</body>

</html>
