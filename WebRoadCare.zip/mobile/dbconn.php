<?php
// Database connection parameters
$host = "localhost"; // Hostname of the database server
$username = "root"; // Your database username
$password = ""; // Your database password
$database = "mobiledb"; // The name of your database

// Create connection
$link = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$link) {
    die("Error: Unable to connect to MySQL. " . mysqli_connect_error());
}
?>