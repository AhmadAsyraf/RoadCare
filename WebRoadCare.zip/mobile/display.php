<?php
// Include database connection file
include 'dbconn.php';

// Function to handle image upload
function uploadImage($file, $dbConnection) {
    $targetDir = "uploads/";

    // Check if the directory exists, create it if not
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    $targetFile = $targetDir . basename($file["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($file["tmp_name"]);
    if ($check !== false) {
        // File is an image
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    // Check if file already exists
    if (file_exists($targetFile)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }

    // Check file size (you can adjust the size limit)
    if ($file["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow only certain file formats (you can extend the list)
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        // If everything is ok, try to upload file
        if (move_uploaded_file($file["tmp_name"], $targetFile)) {
            // File uploaded successfully, save the file path to the database
            $filePath = $targetFile;
            $sql = "INSERT INTO image (pic) VALUES ('$filePath')";
            if (mysqli_query($dbConnection, $sql)) {
                echo "The file " . htmlspecialchars(basename($file["name"])) . " has been uploaded and saved to the database.";
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($dbConnection);
            }
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["image"])) {
    // Call the function to handle image upload
    uploadImage($_FILES["image"], $conn);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Image Upload</title>
</head>
<body>
    <h2>Upload Image</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
        Select image to upload:
        <input type="file" name="image" id="image">
        <input type="submit" value="Upload Image" name="submit">
    </form>

    <h2>Uploaded Image</h2>
    <?php
    // Display the latest uploaded image
    $result = mysqli_query($conn, "SELECT pic FROM image ORDER BY id DESC LIMIT 1");
    if ($row = mysqli_fetch_assoc($result)) {
        echo '<img src="' . $row['pic'] . '" alt="Uploaded Image" style="max-width: 500px;">';
    } else {
        echo "No image uploaded yet.";
    }
    ?>
</body>
</html>
