-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 08, 2024 at 03:25 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobiledb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `report` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL DEFAULT current_timestamp(),
  `latitude` double NOT NULL,
  `longitude` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `id` int(11) NOT NULL,
  `pic` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`id`, `pic`) VALUES
(1, 0x75706c6f6164732f776861742d77652d646f2d312e6a7067),
(2, 0x75706c6f6164732f6f75722d766973696f6e2e6a7067);

-- --------------------------------------------------------

--
-- Table structure for table `map`
--

CREATE TABLE `map` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `map`
--

INSERT INTO `map` (`id`, `name`, `email`, `Description`, `location`, `latitude`, `longitude`) VALUES
(1, '', '', '', 'Seksyen 13, Shah Alam ', 3.07, 100.52),
(2, '', '', '', 'Muar,Johor', 2.04, 102.56),
(3, 'Fikri', 'fik99@gmail.com', 'Potholes', 'Muar,Johor', 2.044, 102.56),
(4, 'Aisyah', 'Ai00@gmail.com', 'Construction', 'Seksyen13, Shah Alam', 3.07, 101.52);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image_name` blob NOT NULL,
  `author` varchar(100) NOT NULL,
  `publish_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `description`, `image_name`, `author`, `publish_date`) VALUES
(46, 'JPJ members were injured when a driver ran away from a roadblock', 'An enforcement officer of the Kelantan Road Transport Department JPJ was injured after being hit by a car that ran away while passing through a road block', 0x6a706a2e6a7067, 'Bernama', '2024-01-20'),
(47, 'JKR received 267 reports of road damage due to floods in six states', 'The Public Works Department (JKR) received a total of 267 reports regarding damage to roads, bridges, collapsed slopes and subsidence involving six flood-affected states.\r\n', 0x706f6c6963652e6a7067, 'Bernama', '2024-01-20'),
(48, 'Pahang police requested an inquest in the case of the accident man in Cameron Highlands', 'Pahang Police will refer to the state prosecution to make a request for an inquest following the death of a man who was involved in an accident at Kilometer 74.5 of Jalan Besar Kuala Terla near Lavender Garden, Cameron Highlands in November last year.', 0x6a6c6e2e6a7067, 'Sinar Harian', '2024-01-20'),
(49, 'Two brothers died, two were seriously injured in a two-car accident in Kota Tinggi', 'Two brothers died while two others were seriously injured including a five-year-old boy in a road accident involving two vehicles on Jalan Kota Tinggi.', 0x506963747572652e6a7067, 'Awani', '2024-02-02'),
(50, 'Two burnt to death in car-container lorry collision', 'A man and a woman were burnt to death when a car they were travelling in, burst into flames upon colliding with a container lorry.', 0x38313639343036363031315f6b656d616c616e67616e2e6a7067, 'Bernama', '2023-09-07'),
(51, 'Aidiladha: Slow moving traffic on NSE due to accidents, breakdowns', 'PLUS said traffic was slow from Jawi to Bandar Cassia River in Penang due to an accident at Kilometre (KM) 155.3 (northbound).', 0x35313638383033363932325f54426d656e6f72616a70672e6a7067, 'Bernama', '2023-06-29'),
(52, 'Three burnt to death in Ipoh crash', 'The three individuals were burnt to death when the car they were travelling in crashed into a garbage truck at Bercham Industrial Area area.\r\n', 0x36313639393931303832375f52656e74756e672e6a7067, 'Bernama', '2023-11-14'),
(53, '598,635 road accidents recorded in 2023 - Bukit Aman', 'A total of 598,635 road accidents were reported nationwide from Jan 1 to Dec 30 last year.', 0x36313730343038313636375f70696e74756d6173756b7064726d62752e6a7067, 'Bernama', '2024-01-01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `map`
--
ALTER TABLE `map`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `map`
--
ALTER TABLE `map`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
